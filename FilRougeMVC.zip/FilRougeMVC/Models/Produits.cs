﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Produits
    {
        private int produitsId;
        public int ProduitsId
        {
            get { return produitsId; }
            set { produitsId = value; }
        }

        private string nomProduit;
        [Required]
        public string NomProduit
        {
            get { return nomProduit; }
            set { nomProduit = value; }
        }

        


        private string description;
        [Required]
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        private decimal prixUnitaire;
        [Column("prixUnitaire", TypeName = "money"), Required]
        public decimal PrixUnitaire
        {
            get { return prixUnitaire; }
            set { prixUnitaire = value; }
        }

        private int stockDuProduit;
        [Required]
        public int StockDuProduit
        {
            get { return stockDuProduit; }
            set { stockDuProduit = value; }
        }

        public virtual CatalogueProduits catalogue { get; set; }

        public virtual Promotion promotion { get; set; }

        public virtual ICollection<Client> client { get; set; }

        public virtual ICollection<Commande> commande { get; set; }

    }
}