﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class CatalogueProduits
    {
        private int catalogueProduitsId;
        public int CatalogueProduitsId
        {
            get { return catalogueProduitsId; }
            set { catalogueProduitsId = value; }
        }

        private List<Produits> catalogue;
        public List<Produits> Catalogue
        {
            get { return catalogue; }
            set { catalogue = value; }
        }

    }
}