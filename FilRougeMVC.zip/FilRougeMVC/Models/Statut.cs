﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Statut
    {
        private int statutId;

        public int StatutId
        {
            get { return statutId; }
            set { statutId = value; }
        }


        public enum EtatStatut
        {
            EnCours, EnAttente, Abandonné, Terminé
        }
        public EtatStatut etatStatut { get; set; }

        public virtual ICollection<Commande> commande { get; set; }
    }
}