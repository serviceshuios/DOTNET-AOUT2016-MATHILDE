﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Utilisateur
    {
        private int utilisateurId;

        public int UtilisateurId
        {
            get { return utilisateurId; }
            set { utilisateurId = value; }
        }

        private string civilite;
        
        public string Civilite
        {
            get { return civilite; }
            set { civilite = value; }
        }


        private string nom;
        
        public string Nom
        {
            get { return nom; }
            set { nom = value; }
        }

        private string prenom;
        
        public string Prenom
        {
            get { return prenom; }
            set { prenom = value; }
        }

        private string email;
        [Column("Email", TypeName = "varchar"), Index(IsUnique = true)]
        
        public string Email
        {
            get { return email; }
            set { email = value; }
        }

       

       
    }
}