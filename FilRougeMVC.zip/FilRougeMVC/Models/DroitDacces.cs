﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class DroitDacces
    {
        private int droitDaccesId;

        public int DroitDaccesId
        {
            get { return droitDaccesId; }
            set { droitDaccesId = value; }
        }

        private string identifiant;
        [Required]
        public string Identifiant
        {
            get { return identifiant; }
            set { identifiant = value; }
        }

        private string password;
        [Required]
        [DataType(DataType.Password)]
        public string Password
        {
            get { return password; }
            set { password = value; }
        }


        private string confirmationPassword;
        [Required]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Veuillez saisir un mot de passe identique")]
        public string ConfirmationPassword
        {
            get { return confirmationPassword; }
            set { confirmationPassword = value; }
        }

        public virtual ICollection<Administrateur> administrateur { get; set; }


     
    }
}