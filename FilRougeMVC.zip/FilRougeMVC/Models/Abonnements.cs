﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Abonnements
    {
        private int abonnementsId;

        public int AbonnementsId
        {
            get { return abonnementsId; }
            set { abonnementsId = value; }
        }

        public virtual ICollection<Client> client { get; set; }
    }
}