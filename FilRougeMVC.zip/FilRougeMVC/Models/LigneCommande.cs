﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class LigneCommande
    {
        [Key, Column(Order = 0)]
        public int ProduitId { get; set; }
        [Key, Column(Order = 1)]
        public int CommandeId { get; set; }

        public virtual Produits produit { get; set; }
        public virtual Commande commande { get; set; }

        private int quantite;
        public int Quantite
        {
            get { return quantite; }
            set { quantite = value; }
        }


        public virtual PanierArticles panier { get; set; }
    }
}