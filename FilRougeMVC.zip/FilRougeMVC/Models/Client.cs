﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Client : Utilisateur
    {
        private int clientId;
        [Required(ErrorMessage = "Le Champ Nom ne doit pas être vide")]
        public int ClientId
        {
            get { return clientId; }
            set { clientId = value; }
        }
       
        private DateTime dateDeNaissance;
        [DataType(DataType.Date)]
        [Display(Name = " Date de Naissance")]
        [Required]
        public DateTime DateDeNaissance
        {
            get { return dateDeNaissance; }
            set { dateDeNaissance = value; }
        }

        private string telephone;
        [Required]
        [MaxLength(10),MinLength(10)]
        public string Telephone
        {
            get { return telephone; }
            set { telephone = value; }
        }

        private string nCarteFidelite;
        [MaxLength(10), MinLength(10)]
        public string NCarteFidelite
        {
            get { return nCarteFidelite; }
            set { nCarteFidelite = value; }
        }

        private int nPoints;
        public int NPoints
        {
            get { return nPoints; }
            set { nPoints = value; }
        }

        private DateTime dateDeCreationCompte;
        [Required]
        [DataType(DataType.Date)]
        [Display(Name = " Creation de Compte")]
        public DateTime DateDecreationCompte
        {
            get { return dateDeCreationCompte; }
            set { dateDeCreationCompte = value; }
        }

        private bool actif;
        public bool Actif
        {
            get { return actif; }
            set { actif = value; }
        }

        private bool compteASupprimer;

        public bool CompteASupprimer
        {
            get { return compteASupprimer; }
            set { compteASupprimer = value; }
        }


        private string login;
        [Required]
        public string Login
        {
            get { return login; }
            set { login = value; }
        }


        private string motDePasse;
        [Required]
        [DataType(DataType.Password)]
        public string MotDePasse
        {
            get { return motDePasse; }
            set { motDePasse = value; }
        }

        private string confirmationMdp;
        [Required]
        [DataType(DataType.Password)]
        [Compare("MotDePasse", ErrorMessage = "Veuillez saisir un mot de passe identique")]
        public string ConfirmationMdp
        {
            get { return confirmationMdp; }
            set { confirmationMdp = value; }
        }



        public virtual Adresse adresse { get; set; }

        public virtual Cadeau cadeau { get; set; }

        public virtual Fidelite fidelite { get; set; }

        public virtual Abonnements abonnements { get; set; }

        public virtual ModeDePaiement modeDePaiement { get; set; }

        public virtual Commande commande { get; set; }

        public virtual ICollection<Produits> produit { get; set; }
    }
}