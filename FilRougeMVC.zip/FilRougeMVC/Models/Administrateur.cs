﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Administrateur : Utilisateur
    {
        private int administrateurId;

        public int AdministrateurId
        {
            get { return administrateurId; }
            set { administrateurId = value; }
        }

        public virtual ICollection<Promotion> promotion { get; set; }

        public virtual DroitDacces droitDacces { get; set; }


    }
}