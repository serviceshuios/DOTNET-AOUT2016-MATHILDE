﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Promotion
    {
        private int promotionId;

        public int PromotionId
        {
            get { return promotionId; }
            set { promotionId = value; }
        }

        public virtual ICollection<Produits> produit { get; set; }

        public virtual Administrateur administrateur { get; set; }
    }
}