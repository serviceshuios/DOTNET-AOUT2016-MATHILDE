﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class PanierArticles
    {
        private int panierArticlesId;
        public int PanierArticlesId
        {
            get { return panierArticlesId; }
            set { panierArticlesId = value; }
        }

        private List<LigneCommande> panier;
        public List<LigneCommande> Panier
        {
            get { return panier; }
            set { panier = value; }
        }


        private decimal prixTotal;
        [Column("prixTotal", TypeName = "money"), Required]
        public decimal PrixTotal
        {
            get { return prixTotal; }
            set { prixTotal = value; }
        }

        private int fraisDeLivraison;
        public int FraisDeLivraison
        {
            get { return fraisDeLivraison; }
            set { fraisDeLivraison = value; }
        }

    }
}