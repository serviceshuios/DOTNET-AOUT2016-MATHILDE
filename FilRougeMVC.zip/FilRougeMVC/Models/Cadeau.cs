﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Cadeau
    {
        private int cadeauId;

        public int CadeauId
        {
            get { return cadeauId; }
            set { cadeauId = value; }
        }

        private int pointAnniversaire;

        public int PointAnniversaire
        {
            get { return pointAnniversaire; }
            set { pointAnniversaire = value; }
        }

        public virtual ICollection<Client> client { get; set; }
    }
}