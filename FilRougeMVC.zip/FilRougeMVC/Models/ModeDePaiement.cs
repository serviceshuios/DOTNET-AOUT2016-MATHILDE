﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class ModeDePaiement
    {
        private int modeDePaiementId;

        public int ModeDePaiementId
        {
            get { return modeDePaiementId; }
            set { modeDePaiementId = value; }
        }


        private int numOrdrePaiement;
        [Required]
        public int NumOrdrePaiement
        {
            get { return numOrdrePaiement; }
            set { numOrdrePaiement = value; }
        }

        public virtual ICollection<Client> client { get; set; }

        public enum Paiement
        {
            Facture, CarteCredit, Cheque, Virement
        }
        public Paiement paiement {get;set;}




    }
}