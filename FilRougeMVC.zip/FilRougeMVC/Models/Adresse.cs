﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Adresse
    {
        private int adresseId;

        public int AdresseId
        {
            get { return adresseId; }
            set { adresseId = value; }
        }

        private string nomRue;
        [Required]
        public string NomRue
        {
            get { return nomRue; }
            set { nomRue = value; }
        }

        private int codePostal;
        [Required]
        public int CodePostal
        {
            get { return codePostal; }
            set { codePostal = value; }
        }

        private string ville;
        [Required]
        public string Ville
        {
            get { return ville; }
            set { ville = value; }
        }

        private string pays;
        [Required]
        public string Pays
        {
            get { return pays; }
            set { pays = value; }
        }


        public virtual ICollection<Client> client { get; set; }
    }
}