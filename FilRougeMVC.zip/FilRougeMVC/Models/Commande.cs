﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Commande
    {
        private int commandeId;
        public int CommandeId
        {
            get { return commandeId; }
            set { commandeId = value; }
        }

        private int numFacture;
        [Required]
        public int NumFacture
        {
            get { return numFacture; }
            set { numFacture = value; }
        }

        private int numColis;
        [Required]
        public int NumColis
        {
            get { return numColis; }
            set { numColis = value; }
        }

        private string commentaires;
        [Required]
        public string Commentaires
        {
            get { return commentaires; }
            set { commentaires = value; }
        }

        private DateTime dateExpedition;
        [Required]
        public DateTime DateExpedition
        {
            get { return dateExpedition; }
            set { dateExpedition = value; }
        }

        private DateTime dateLivraison;
        [Required]
        public DateTime DateLivraison
        {
            get { return dateLivraison; }
            set { dateLivraison = value; }
        }

        private DateTime dateCommande;
        [Required]
        public DateTime DateCommande
        {
            get { return dateCommande; }
            set { dateCommande = value; }
        }

        private string facture;
        [Required]
        public string Facture
        {
            get { return facture; }
            set { facture = value; }
        }

        private int bonDeLivraison;
        [Required]
        public int BonDeLivraison
        {
            get { return bonDeLivraison; }
            set { bonDeLivraison = value; }
        }





        public virtual ICollection<Client> client { get; set; }

        public virtual ICollection<Produits> produit { get; set; }
    }
}