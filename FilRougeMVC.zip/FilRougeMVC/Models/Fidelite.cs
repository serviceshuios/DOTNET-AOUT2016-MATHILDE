﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Models
{
    public class Fidelite
    {
        private int fideliteId;

        public int FideliteId
        {
            get { return fideliteId; }
            set { fideliteId = value; }
        }

        public virtual ICollection<Client> client { get; set; }
    }
}