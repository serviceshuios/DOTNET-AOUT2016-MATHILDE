﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FilRouge.Models;

namespace FilRouge.Metier
{
    public interface IMetierAdmn
    {
        Produits AjouterProduit(Produits p);
        ICollection<Produits> findAll();
        void SupprimerProduit(int idProduit);
        Produits findProduit(int idProduit);
        ICollection<Produits> findProduitsByName(string name);
        Produits Update(Produits p);

        Client AjouterClient(Client c);
        ICollection<Client> findAllClients();
        ICollection<Client> findClientByName(string name);


        //signature pas sure
        DroitDacces AuthentificationAdmn(DroitDacces d);
        DroitDacces AjouterAdministrateur(DroitDacces d);
        void SupprimerAdmin(int idAdministarteur);
        DroitDacces ModifierAdministrateur(DroitDacces d);
        Client ModifierClient(Client c);
        void SupprimerClient(int idClient);

        Client findClient(int idClient);
        ICollection<Commande> ListerCommande();
        void SupprimerCommande(int idCommande);
        //Commande NotificationParEmail(Commande com);

       



        Promotion RemiseProduit(int idPromo);
        bool RemiseAnniversaire(Cadeau cad);

        bool RemiseFidelite(Fidelite f);

      

        ICollection<AvisConsommateur> AfficherAvisProduit();

      

        ICollection<LigneCommande> AfficherLigneCommande();
        ICollection<Historique> AfficherDerniersArticlesConsultes();

    }
}
