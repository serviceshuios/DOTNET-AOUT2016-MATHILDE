﻿using FilRouge.Dao;
using FilRouge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FilRouge.Metier
{
    public class MetierImplAdmn : IMetierAdmn
    {
        public IDao Idao = new DaoImpl();
        public ICollection<AvisConsommateur> AfficherAvisProduit()
        {
            return Idao.AfficherAvisProduit();
        }

        public ICollection<Historique> AfficherDerniersArticlesConsultes()
        {
            return Idao.AfficherDerniersArticlesConsultes();
        }

        public ICollection<LigneCommande> AfficherLigneCommande()
        {
            return Idao.AfficherLigneCommande();
        }

        public Client AjouterClient(Client c)
        {
            return Idao.AjouterClient(c);
        }

        public Produits AjouterProduit(Produits p)
        {
            return Idao.AjouterProduit(p);
        }

        public DroitDacces AuthentificationAdmn(DroitDacces d)
        {
            return Idao.AuthentificationAdmn(d);
        }

       

        public ICollection<Produits> findAll()
        {
            return Idao.findAll();
        }

        public ICollection<Client> findAllClients()
        {
            return Idao.findAllClients();
        }

        public ICollection<Client> findClientByName(string name)
        {
            return Idao.findClientByName(name);
        }

        public Produits findProduit(int idProduit)
        {
            return Idao.findProduit(idProduit);
        }

        public ICollection<Produits> findProduitsByName(string name)
        {
            return Idao.findProduitsByName(name);
        }

        public ICollection<Commande> ListerCommande()
        {
            return Idao.ListerCommande();
        }

        public Client ModifierClient(Client c)
        {
            return Idao.ModifierClient(c);

        }

        public Client findClient(int idClient)
        {
            return Idao.findClient(idClient);
        }

        /*public Commande NotificationParEmail(Commande com)
        {
            return Idao.NotificationParEmail(com);
        }*/


        public DroitDacces AjouterAdministrateur(DroitDacces d)
        {
            return Idao.AjouterAdministrateur(d);
        }
        public void SupprimerAdmin(int idAdministarteur)
        {
            Idao.SupprimerAdmin(idAdministarteur);
        }
        public DroitDacces ModifierAdministrateur(DroitDacces d)
        {
            return Idao.ModifierAdministrateur(d);
        }

        public bool RemiseAnniversaire(Cadeau cad)
        {
            return Idao.RemiseAnniversaire(cad);
        }

        public bool RemiseFidelite(Fidelite f)
        {
           return Idao.RemiseFidelite(f);
        }

        public Promotion RemiseProduit(int idPromo)
        {
            return Idao.RemiseProduit(idPromo);
        }
      

        public void SupprimerClient(int idClient)
        {
            Idao.SupprimerClient(idClient);
        }

        public void SupprimerCommande(int idCommande)
        {
            Idao.SupprimerCommande(idCommande);
        }
        public void SupprimerProduit(int idProduit)
        {
            Idao.SupprimerProduit(idProduit);
        }

        public Produits Update(Produits p)
        {
            return Idao.Update(p);
        }

        public Client AuthentificationClient(Client c)
        {
            return Idao.AuthentificationClient(c);
        }

       

    }
}