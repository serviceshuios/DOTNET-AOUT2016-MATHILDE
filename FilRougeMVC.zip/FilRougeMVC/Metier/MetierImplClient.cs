﻿using FilRouge.Dao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FilRouge.Models;

namespace FilRouge.Metier
{
    public class MetierImplClient : IMetierClient
    {
        public IDao Idao = new DaoImpl();

        public AdresseClient AjouterAdresse(AdresseClient ac)
        {
            return Idao.AjouterAdresse(ac);
        }
    }

}