﻿using FilRouge.Dao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FilRouge.Models;

namespace FilRouge.Metier
{
    public class MetierImplClient : IMetierClient
    {
        public IDao Idao = new DaoImpl();

        public AdresseClient AjouterAdresse(AdresseClient ac)
        {
            throw new NotImplementedException();
        }

        public Adresse AjouterAdresse(Adresse a)
        {
            return Idao.AjouterAdresse(a);
        }
        public Client AjouterClient(Client c)
        {
            return Idao.AjouterClient(c);
        }

        public Client AuthentificationClient(Client c)
        {
            return Idao.AuthentificationClient(c);
        }
    }

}