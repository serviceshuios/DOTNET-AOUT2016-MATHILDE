﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using FilRouge.Models;
using System.Data.Entity;

namespace FilRouge.Dao
{
    public class DaoImpl : IDao
    {
        public ICollection<AvisConsommateur> AfficherAvisProduit()
        {
            using (var db = new ApplicationContext())
            {

                return db.AvisConsommateurs.ToList();
            }
        }

        public ICollection<Historique> AfficherDerniersArticlesConsultes()
        {
            using (var db = new ApplicationContext())
            {
                return db.Historique.ToList();
            }
        }

        public ICollection<LigneCommande> AfficherLigneCommande()
        {
            using (var db = new ApplicationContext())
            {

                return db.LigneCommandes.ToList();
            }
        }

        public Client AjouterClient(Client c)
        {
            using (var db = new ApplicationContext())
            {
                db.Client.Add(c);
                db.SaveChanges();
                return c;

            }
        }

        public Produits AjouterProduit(Produits p)
        {
            using (var db = new ApplicationContext())
            {
                db.Produit.Add(p);
                db.SaveChanges();
                return p;
            }
        }

        public DroitDacces AuthentificationAdmn(DroitDacces d)
        {
            using (var db = new ApplicationContext())
            {
                var user = db.DroitD_acces.FirstOrDefault(
                    u => u.Identifiant == d.Identifiant && u.Password == d.Password);
                return user;

            }
        }



        public Client AuthentificationClient(Client c)
        {
            using (var db = new ApplicationContext())
            {
                var user = db.Client.FirstOrDefault(
                    u => u.Login == c.Login && u.MotDePasse == c.MotDePasse);
                return user;

            }
        }

        public ICollection<Produits> findAll()
        {
            using (var db = new ApplicationContext())
            {
                return db.Produit.ToList();
            }
        }

        public ICollection<Client> findAllClients()
        {
            using (var db = new ApplicationContext())
            {
                return db.Client.ToList();
            }

        }

        public ICollection<Client> findClientByName(string name)
        {
            using (var db = new ApplicationContext())
            {
                //expression lambda
                //return db.Produits.Where(p => p.nom.Contains(name) == name).ToList();
                //par linq
                var req = from c in db.Client
                          where c.Nom.Contains(name)
                          select c;
                return req.ToList();
            }
        }

        public Produits findProduit(int idProduit)
        {
            using (var db = new ApplicationContext())
            {
                return db.Produit.Find(idProduit);
            }
        }


        public Client findClient(int idClient)
        {
            using (var db = new ApplicationContext())
            {
                return db.Client.Find(idClient);
            }
        }

        public ICollection<Produits> findProduitsByName(string name)
        {
            using (var db = new ApplicationContext())
            {
                //expression lambda
                //return db.Produits.Where(p => p.nom.Contains(name) == name).ToList();
                //par linq
                var req = from p in db.Produit
                          where p.NomProduit.Contains(name)
                          select p;
                return req.ToList();
            }
        }

        public ICollection<Commande> ListerCommande()
        {
            using (var db = new ApplicationContext())
            {
                return db.Commande.ToList();
            }
        }

       
        public Client ModifierClient(Client c)
        {
            using (var db = new ApplicationContext())
            {
                db.Entry(c).State = EntityState.Modified;
                db.SaveChanges();
                return c;
            }
        }



       public bool RemiseAnniversaire(Cadeau cad)
        {

            /*if (Client.DateDeNaissance.Day == DateTime.Now.Day && Client.DateDeNaissance.Month == DateTime.Now.Month)
                {
                    Client.NPoints = 50;
                }
                return false;*/
            throw new NotImplementedException();

        }


  

       

        public bool RemiseFidelite(Fidelite f)
        {
            /* if (client.Dépense <= 1000)
             {
                 Depôt(primeAnniversaire);
                 return true;
             }

             if (client.Dépense >= 1000)
             {

                 Depôt(primeAnniversaire + 0.01 * dépenseClient);
                 return true;

             }*/
            throw new NotImplementedException();

        }

      
        public void SupprimerClient(int idClient)
        {
            using (var db = new ApplicationContext())
            {
                Client c = db.Client.Find(idClient);
                db.Client.Remove(c);
                db.SaveChanges();
            }
        }

        public DroitDacces AjouterAdministrateur(DroitDacces d)
        {
            using (var db = new ApplicationContext())
            {
                db.DroitD_acces.Add(d);
                db.SaveChanges();
                return d;
            }
        }
        public void SupprimerAdmin(int idAdministrateur)
        {
            using (var db = new ApplicationContext())
            {
                DroitDacces d = db.DroitD_acces.Find(idAdministrateur);
                db.DroitD_acces.Remove(d);
                db.SaveChanges();
            }
        }
        public DroitDacces ModifierAdministrateur(DroitDacces d)
        {
            using (var db = new ApplicationContext())
            {
                db.Entry(d).State = EntityState.Modified;
                db.SaveChanges();
                return d;
            }
        }

        public void SupprimerCommande(int idCommande)
        {
            using (var db = new ApplicationContext())
            {
                Commande com = db.Commande.Find(idCommande);
                db.Commande.Remove(com);
                db.SaveChanges();
            }
        }

        public void SupprimerProduit(int idProduit)
        {
            using (var db = new ApplicationContext())
            {
                Produits p = db.Produit.Find(idProduit);
                db.Produit.Remove(p);
                db.SaveChanges();
            }
        }

        public Produits Update(Produits p)
        {
            using (var db = new ApplicationContext())
            {

                db.Entry(p).State = EntityState.Modified;
                db.SaveChanges();
                return p;
            }
        }

     

        public Promotion RemiseProduit(int idPromo)
        {
            throw new NotImplementedException();
        }

        public Adresse AjouterAdresse(Adresse a)
        {
            throw new NotImplementedException();
        }








        /*public Commande NotificationParEmail(Commande com)
       {
          si la commande est prete, envoie par email au client un email;

       }*/
    }
}