﻿using FilRouge.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace FilRouge.Dao
{
    public class ApplicationContext : DbContext
    {
        public DbSet<Abonnements> Abonnements { get; set; }
        public DbSet<Administrateur> Admnistrateur { get; set; }
        public DbSet<Adresse> Adresse { get; set; }
        public DbSet<AdresseClient> AdresseClient { get; set; }
        public DbSet<AvisConsommateur> AvisConsommateurs { get; set; }
        public DbSet<Cadeau> Cadeau { get; set; }
        public DbSet<CatalogueProduits> Catalogue { get; set; }
        public DbSet<Client> Client { get; set; }
        public DbSet<Commande> Commande { get; set; }
        public DbSet<DroitDacces> DroitD_acces { get; set; }
        public DbSet<Fidelite> Fidelite { get; set; }
        public DbSet<Historique> Historique { get; set; }
        public DbSet<LigneCommande> LigneCommandes { get; set; }
        public DbSet<ModeDePaiement> ModeDePaiement { get; set; }
        public DbSet<PanierArticles> Panier { get; set; }
        public DbSet<Produits> Produit { get; set; }
        public DbSet<Promotion> Promotion { get; set; }
        public DbSet<Statut> Statut { get; set; }
        public DbSet<Utilisateur> Utilisateur { get; set; }
    }
}