﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FilRouge.Models;


namespace FilRouge.Dao
{
    public interface IDao
    {
        //signature sure
        Produits AjouterProduit(Produits p);
        ICollection<Produits> findAll();
        void SupprimerProduit(int idProduit);
        Produits Update(Produits p);
        Produits findProduit(int idProduit);
        ICollection<Produits> findProduitsByName(string name);

        Client AjouterClient(Client c);
         void SupprimerClient(int idClient);
        Client ModifierClient(Client c);
        Client AuthentificationClient(Client c);
        ICollection<Client> findAllClients();
        Client findClient(int idClient);
        ICollection<Client> findClientByName(string name);

        //signature presque sure
        DroitDacces AjouterAdministrateur(DroitDacces d);
        void SupprimerAdmin(int idAdministarteur);
        DroitDacces ModifierAdministrateur(DroitDacces d);

      




        void SupprimerCommande(int idCommande);
        ICollection<Commande> ListerCommande();

        DroitDacces AuthentificationAdmn(DroitDacces d);
        //Commande NotificationParEmail(Commande com);

        


        Promotion RemiseProduit(int idPromo);
        bool RemiseAnniversaire(Cadeau cad);

        bool RemiseFidelite(Fidelite f);

        //signature pas sure



        ICollection<AvisConsommateur> AfficherAvisProduit();

        ICollection<LigneCommande> AfficherLigneCommande();
        ICollection<Historique> AfficherDerniersArticlesConsultes();

        Adresse AjouterAdresse(Adresse a);

       

        //signature methode client(à implementer après)




        /*AdresseLivraison AjouterAdresseLivraison(AdresseLivraison al);
        Adressefacturation AjouterAdresseFacturation(AdresseFacturation af);
        Client DonnerAvisProduit(Produits p, Client c);
        PanierArticles FairePanier(PanierArticles pa);
        PanierArticles ModifierPanier(PanierArticles pa);
        PanierArticles AfficherPanier(int idPanierArticles);
        PanierArticles SupprProduitPanier(int idProduit);
        void SupprimerPanier(int idPanierArticles);
        AvisConsommateur EcrireCommentaire(string comment);
        AvisConsommateur EcrireAvisProduit(string comment);
        void SuupprimerAvis(idAvisConsommateur);
        AvisConsommateur ModifierAvis(string comment);

       
        AdresseFacturation ModifierAdresse(AdresseFacturation af);
        void SupprimerAdresse(idAdresse);
        AdresseFacturation AjouterAdresse(AdresseFacturation af);
        AdresseLivraison ModifierAdresse(AdresseLivraison al);


        Client AjouterInfoCompte(Client c);
        Client ModifierCompte(Client c);
        void SupprimerInfoCompte(Client c);
        Client DemandeSuppressionCompte(Client c, Administrateur admn);

        Commande AfficherSuiviCommande();

        Abonnements AjouterAbonnement(Abonnements ab);
        void SupprimerAbonnement(Abonnements ab);
        Abonnements ModifierAbonnement(Abonnements ab);
        Abonnements AfficherAbonnement(Abonnements ab);
      
        Statut AfficherStatutCommande(Statut s);

        void TelechargerFacturePDF(int idCommande);
        void TelechargerBlPDF(int idCommande);
        void ImprimerFacturePDF(int idCommande);

        void ImprimerBlPDF(int idCommande);


        void Payer();*/

    }
}
