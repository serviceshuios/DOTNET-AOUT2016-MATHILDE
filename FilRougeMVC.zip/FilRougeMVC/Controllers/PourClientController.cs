﻿using FilRouge.Metier;
using FilRouge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class PourClientController : Controller
    {
       IMetierClient ImetierC = new MetierImplClient();

        // GET: PourClient
        public ActionResult Index()
        {
            return View();
        }

      

        public ActionResult S_Ajouter()
        {
            return View();
        }


       [HttpPost]
        public ActionResult S_Ajouter(Client c)
        {
            if (ModelState.IsValid)
            {
                ImetierC.AjouterClient(c);
                return View();
            }
            else { return View(c); }
        }

        public ActionResult AuthentificationClient()
         {

             return View();
         }

        [HttpPost]
         public ActionResult AuthentificationClient(Client c)
         {
             var user = ImetierC.AuthentificationClient(c);
             if (user != null)
             {
                 Session["ClientId"] = user.ClientId;
                 Session["Nom"] = user.Nom;
                 Session["Prenom"] = user.Prenom;
                 return RedirectToAction("LoggedIn");

             }
             else
             {
                 ModelState.AddModelError("", "Le mot de passe ou le nom d'identifiant est incorrect");
                 return View();
             }
         }


         public ActionResult LoggedIn()
         {
             if (Session["ClientId"] != null)
             {
                 return View();
             }
             else
             {
                 return RedirectToAction("AuthentificationClient");
             }
         }

         public ActionResult Logout()
         {
             Session["ClientId"] = null;
             Session["Prenom"] = null;
             return RedirectToAction("AuthentificationClient");
         }

    }
}