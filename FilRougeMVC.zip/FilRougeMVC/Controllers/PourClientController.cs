﻿using FilRouge.Metier;
using FilRouge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class PourClientController : Controller
    {
       //public IMetierClient Imetier = new MetierImplClient();

        // GET: PourClient
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AjouterAdresse()
        {
            return View();
        }


       /* [HttpPost]
        public ActionResult AjouterAdresse(Adresse ad)
        {
            if (ModelState.IsValid)
            {
                Imetier.AjouterAdresse(ad);
                return View();
            }
            else { return View(ad); }
        }*/

        /*public ActionResult S_Ajouter()
        {
            return View();
        }


        [HttpPost]
        public ActionResult S_Ajouter(Client c)
        {
            if (ModelState.IsValid)
            {
                Imetier
                return View();
            }
            else { return View(c); }
        }*/
    }
}