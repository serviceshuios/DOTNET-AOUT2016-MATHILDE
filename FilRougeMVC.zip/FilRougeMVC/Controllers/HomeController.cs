﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Bienvenue Cher Administrateur,";
            return View();
        }

        public ActionResult Client()
        {
            ViewBag.Message = "Opérations Client";

            return View();
        }

        public ActionResult Produit()
        {
            ViewBag.Message = "Opérations Produit";

            return View();
        }

        public ActionResult Commande()
        {
            ViewBag.Message = "Opérations Commande";

            return View();
        }
    }
}