﻿using FilRouge.Metier;
using FilRouge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class AdministrateurController : Controller
    {
        public IMetierAdmn Imetier = new MetierImplAdmn();
        // GET: Administrateur
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AuthentificationAdmn()
        {
            return View();
        }
        
         [HttpPost]
         public ActionResult AuthentificationAdmn(DroitDacces d)
         {
             var admn = Imetier.AuthentificationAdmn(d);
             if (admn != null)
             {
                 Session["DroitDaccesId"] = admn.DroitDaccesId;
                Session["Identifiant"] = admn.Identifiant;
                return RedirectToAction("LoggedInAdmn");

             }
             else
             {
                 ModelState.AddModelError("", "Identifiant ou Mot de Passe incorrect");
                 return View();
             }
         }

        public ActionResult LoggedInAdmn()
        {
            if (Session["DroitDaccesId"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("AuthentificationAdmn");
            }
        }

        public ActionResult LogoutAdmn()
        {
            Session["DroitDaccesId"] = null;
            Session["Identifiant"] = null;
            return RedirectToAction("AuthentificationAdmn");
        }


        public ActionResult AjouterAdministrateur()
        {
            return View();
        }


        [HttpPost]
        public ActionResult AjouterAdministrateur(DroitDacces d)
        {
            if (ModelState.IsValid)
            {
                Imetier.AjouterAdministrateur(d);
                return View();
            }
            else { return View(d); }
        }
    }
}