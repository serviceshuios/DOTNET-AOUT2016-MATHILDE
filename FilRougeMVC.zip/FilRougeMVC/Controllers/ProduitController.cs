﻿using FilRouge.Metier;
using FilRouge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class ProduitController : Controller
    {
        public IMetierAdmn Imetier = new MetierImplAdmn();
        // GET: Produit
        public ActionResult Index()
        {
            ICollection<Produits> res = Imetier.findAll();
            return View(res);
        }

        public ActionResult AvisConsommateur()
        {
            ICollection<AvisConsommateur> res = Imetier.AfficherAvisProduit();
            return View(res);
        }


        public ActionResult AjouterProduit()
        {
            
            return View();
        }

        [HttpPost]
        public ActionResult AjouterProduit(Produits p)
        {
            Imetier.AjouterProduit(p);
            return RedirectToAction("Index");
        }
        
        public ActionResult Delete(int id)
        {
            Imetier.SupprimerProduit(id);
            return RedirectToAction("Index");
        }

        public ActionResult Update(int id)
        {
            Produits p = Imetier.findProduit(id);
            return View(p);
        }

        [HttpPost]
        public ActionResult Update(Produits p)
        {
            Imetier.Update(p);
            return RedirectToAction("Index");
        }


        public ActionResult RechercherProduitparNom()
        {
            ICollection<Produits> res = Imetier.findAll();
            return View(res);
        }

        [HttpPost]
        public ActionResult RechercherProduitparNom(string name)
        {
            ICollection<Produits> res = Imetier.findProduitsByName(name);
            return View(res);
        }


    }
}