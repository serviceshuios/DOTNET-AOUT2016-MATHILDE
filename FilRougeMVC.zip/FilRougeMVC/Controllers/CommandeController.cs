﻿using FilRouge.Metier;
using FilRouge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class CommandeController : Controller
    {
        public IMetierAdmn Imetier = new MetierImplAdmn();
        // GET: Commande
        public ActionResult Index()
        {
            ICollection<Commande> res = Imetier.ListerCommande();
            return View(res);
        }


    }
}