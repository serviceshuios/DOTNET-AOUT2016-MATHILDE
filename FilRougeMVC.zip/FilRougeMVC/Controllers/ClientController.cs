﻿using FilRouge.Metier;
using FilRouge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class ClientController : Controller
    {
       
   
        // GET: Client
       
        public IMetierAdmn Imetier = new MetierImplAdmn();
      
       
        public ActionResult Index()
        {
            return View(Imetier.findAllClients());
        }

        public ActionResult AjouterClient()
        {
            return View();
        }


        [HttpPost]
        public ActionResult AjouterClient(Client c)
        {
            if (ModelState.IsValid)
            {
                Imetier.AjouterClient(c);
                return View();
            }
            else { return View(c); }
        }



        public ActionResult DeleteClient(int id)
        {
            Imetier.SupprimerClient(id);
            return RedirectToAction("Index");
        }


        public ActionResult UpdateClient(int id)
        {
            Client c = Imetier.findClient(id);
            return View(c);
        }


        [HttpPost]
        public ActionResult UpdateClient(Client c)
        {
            Imetier.ModifierClient(c);
            return RedirectToAction("Index");
        }



        public ActionResult RechercherClientparNom()
        {
            ICollection<Client> res = Imetier.findAllClients();
            return View(res);
        }

        [HttpPost]
        public ActionResult RechercherClientparNom(string name)
        {
            ICollection<Client> res = Imetier.findClientByName(name);
            return View(res);
        }


        public ActionResult AjouterClientparClient()
        {
            return View();
        }


        [HttpPost]
        public ActionResult AjouterClientparClient(Client c)
        {
            if (ModelState.IsValid)
            {
                Imetier.AjouterClient(c);
                return View();
            }
            else { return View(c); }
        }




        /* public ActionResult AuthentificationClient()
         {

             return View();
         }

         [HttpPost]
         public ActionResult AuthentificationClient(Client c)
         {
             var user = Imetier.AuthentificationClient(c);
             if (user != null)
             {
                 Session["ClientId"] = user.ClientId;
                 Session["Nom"] = user.Nom;
                 Session["Prenom"] = user.Prenom;
                 return RedirectToAction("LoggedIn");

             }
             else
             {
                 ModelState.AddModelError("", "utilisateur ou MMPD incorrect");
                 return View();
             }
         }


         public ActionResult LoggedIn()
         {
             if (Session["ClientId"] != null)
             {
                 return View();
             }
             else
             {
                 return RedirectToAction("AuthentificationClient");
             }
         }

         public ActionResult Logout()
         {
             Session["ClientId"] = null;
             Session["Prenom"] = null;
             return RedirectToAction("AuthentificationClient");
         }*/



    }
}