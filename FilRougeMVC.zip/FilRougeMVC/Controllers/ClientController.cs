﻿using FilRouge.Metier;
using FilRouge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FilRouge.Controllers
{
    public class ClientController : Controller
    {
       
   
        // GET: Client
       
        public IMetierAdmn Imetier = new MetierImplAdmn();
      
       
        public ActionResult Index()
        {
            return View(Imetier.findAllClients());
        }

        public ActionResult AjouterClient()
        {
            return View();
        }


        [HttpPost]
        public ActionResult AjouterClient(Client c)
        {
            if (ModelState.IsValid)
            {
                Imetier.AjouterClient(c);
                return View();
            }
            else { return View(c); }
        }



        public ActionResult DeleteClient(int id)
        {
            Imetier.SupprimerClient(id);
            return RedirectToAction("Index");
        }


        public ActionResult UpdateClient(int id)
        {
            Client c = Imetier.findClient(id);
            return View(c);
        }


        [HttpPost]
        public ActionResult UpdateClient(Client c)
        {
            Imetier.ModifierClient(c);
            return RedirectToAction("Index");
        }



        public ActionResult RechercherClientparNom()
        {
            ICollection<Client> res = Imetier.findAllClients();
            return View(res);
        }

        [HttpPost]
        public ActionResult RechercherClientparNom(string name)
        {
            ICollection<Client> res = Imetier.findClientByName(name);
            return View(res);
        }


       




    }
}